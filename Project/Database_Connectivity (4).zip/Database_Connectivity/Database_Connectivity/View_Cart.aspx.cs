﻿using System;
using System.Collections.Generic;
using System.Configuration;//For Connection String
using System.Data;//For Dataset
//New Namespace
using System.Data.SqlClient;//For Connection
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Database_Connectivity
{
    public partial class View_Cart : System.Web.UI.Page
    {
        SqlConnection con;//For Connection
        SqlCommand cmd;//For insert, update, delete
        SqlDataAdapter da;//For Container
        DataSet ds;//For Select
        string nm;//For Name

        string s = ConfigurationManager.ConnectionStrings["dbcon"].ConnectionString;//For Connection String 
        void getcon()
        {
            con = new SqlConnection(s);
            con.Open();
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["admin"] != null)
            {
                if (!IsPostBack)
                {
                    getcon();

                    da = new SqlDataAdapter("select * from emp_tbl where Email = '" + Session["admin"] + "'", con);
                    ds = new DataSet();
                    da.Fill(ds);

                    nm = ds.Tables[0].Rows[0]["Name"].ToString();
                    string uid = ds.Tables[0].Rows[0]["Id"].ToString();
                    ViewState["uid"] = uid;

                    Label1.Text = "Welcome " + nm;

                    fillcartgrid();
                }
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        void fillcartgrid()
        {
            getcon();
            int uid = Convert.ToInt16(ViewState["uid"]);
            da = new SqlDataAdapter("select c.Cart_Prod_Id, p.Prod_ID, p.Prod_Img, p.Prod_Name, p.Prod_Price, c.Quantity from Product_tbl p INNER JOIN Cart_tbl c ON p.Prod_Id = c.Cart_Prod_Id where c.Cart_User_Id = '" + uid + "'", con);
            ds = new DataSet();
            da.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();

            decimal total = 0;
            foreach(DataRow row in ds.Tables[0].Rows)
            {
                decimal price = Convert.ToDecimal(row["Prod_Price"]);
                int quantity = Convert.ToInt16(row["Quantity"]);
                total += price * quantity;
            }
            Label5.Text = "Total Amount is ₹:" + total;
        }
        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            fillcartgrid();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            int prid = Convert.ToInt16(GridView1.DataKeys[e.RowIndex].Value);
            GridViewRow row = GridView1.Rows[e.RowIndex];

            //DropDownList drpqnt = (row.FindControl("DropDownList1") as DropDownList);
            DropDownList drpqty = (DropDownList)row.FindControl("DropDownList1");
            int qty = int.Parse(drpqty.SelectedValue);

            getcon();
            cmd = new SqlCommand("update Cart_tbl set Quantity='" + qty + "' where Cart_Prod_Id='" + prid + "' AND Cart_User_Id = '" + ViewState["uid"] + "'", con);
            cmd.ExecuteNonQuery();

            GridView1.EditIndex = -1;
            fillcartgrid();
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if(e.CommandName == "cmd_rmv")
            {
                int cid = Convert.ToInt16(e.CommandArgument);
                ViewState["cid"] = cid;

                getcon();
                cmd = new SqlCommand("delete from Cart_tbl where Cart_Prod_Id = '" + ViewState["cid"] +"'", con);
                cmd.ExecuteNonQuery();
                fillcartgrid();
            }
        }
    }
}