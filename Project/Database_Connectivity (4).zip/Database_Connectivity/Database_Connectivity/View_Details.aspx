﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="View_Details.aspx.cs" Inherits="Database_Connectivity.View_Details" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div>
            <center>
                <h1>View Details Page..</h1>
                <p>
                    <asp:Label ID="Label5" runat="server" Text="Label"></asp:Label>
                </p>
                <p>
                    <asp:DataList ID="DataList1" runat="server">
                        <ItemTemplate>
                            <asp:Image ID="Image1" runat="server" Height="400" Width="400" ImageUrl='<%# Eval("Prod_Img") %>' />
                            <br />
                            <asp:Label ID="Label1" runat="server" Text='<%# Eval("Prod_Price") %>'></asp:Label>
                            <br />
                            <asp:Label ID="Label2" runat="server" Text='<%# Eval("Prod_Model") %>'></asp:Label>
                            <br />
                            <asp:Label ID="Label3" runat="server" Text='<%# Eval("Prod_Descrip") %>'></asp:Label>
                            <br />
                            <asp:Label ID="Label4" runat="server" Text='<%# Eval("Prod_Config") %>'></asp:Label>
                            <br />
                            <br />
                            <asp:LinkButton ID="LinkButton1" runat="server" CommandArgument='<%# Eval("Prod_Id") %>' CommandName="cmd_acart">Add to cart</asp:LinkButton>
                        </ItemTemplate>
                    </asp:DataList>
                </p>
            </center>
        </div>
    </form>
</body>
</html>
