﻿using System;
using System.Collections.Generic;
using System.Configuration;//For Connection String
using System.Data;//For Dataset
//New Namespace
using System.Data.SqlClient;//For Connection
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Database_Connectivity
{
    public partial class View_Details : System.Web.UI.Page
    {
        SqlConnection con;//For Connection
        SqlCommand cmd;//For insert, update, delete
        SqlDataAdapter da;//For Container
        DataSet ds;//For Select
        string nm;//For Name

        string s = ConfigurationManager.ConnectionStrings["dbcon"].ConnectionString;//For Connection String 

        void getcon()
        {
            con = new SqlConnection(s);
            con.Open();
        }
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["admin"] != null)
            {
                getcon();

                da = new SqlDataAdapter("select * from emp_tbl where Email = '" + Session["admin"] + "'", con);
                ds = new DataSet();
                da.Fill(ds);

                nm = ds.Tables[0].Rows[0]["Name"].ToString();

                Label5.Text = "Welcome " + nm;

                fillproduct();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        void fillproduct()
        {
            da = new SqlDataAdapter("select * from Product_tbl where Prod_Id = '" + Request.QueryString["pid"] + "'", con);
            ds = new DataSet();
            da.Fill(ds);
            DataList1.DataSource = ds;
            DataList1.DataBind();
        }
    }
}