﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Show_Company.aspx.cs" Inherits="Database_Connectivity.ShowCompany" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div>
            <center>
                <h1>All Company</h1>
                <br />
                <asp:Label ID="Label1" runat="server"></asp:Label>


                <br />
                <br />
                <asp:DataList ID="DataList1" runat="server" CellSpacing="20" RepeatDirection="Horizontal" OnItemCommand="DataList1_ItemCommand">
                    <ItemTemplate>
                        <asp:Image ID="Image1" runat="server" Height="100" Width="100" ImageUrl='<%# Eval("Comp_Cover_img") %>' />
                        <br />
                        <asp:LinkButton ID="LinkButton1" runat="server" CommandArgument='<%# Eval("Comp_id") %>' Text='<%# Eval("Comp_Name") %>' CommandName="cmd_cid"></asp:LinkButton>
                    </ItemTemplate>
                </asp:DataList>


            </center>
        </div>
    </form>
</body>
</html>
