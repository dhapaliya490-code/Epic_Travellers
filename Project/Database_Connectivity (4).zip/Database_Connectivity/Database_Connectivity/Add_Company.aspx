﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Add_Company.aspx.cs" Inherits="Database_Connectivity.Company" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div>
            <h1>
                <asp:LinkButton ID="LinkButton1" runat="server" OnClick="LinkButton1_Click">Go to Products Page</asp:LinkButton>
            </h1>
            <br />
            <br />
            <center>


                <asp:LinkButton ID="LinkButton2" runat="server" OnClick="LinkButton2_Click">Show Company</asp:LinkButton>

                <br />
                <br />
                <br />

                <asp:Label ID="Label1" runat="server"></asp:Label>
                <br />
                <br />
                <table border="2">
                    <tr>
                        <td>Company Name:</td>
                        <td>
                            <asp:TextBox ID="TextBox1" runat="server"></asp:TextBox>
                        </td>
                    </tr>
                    <tr>
                        <td>Company Owner Name:</td>
                        <td>
                            <asp:TextBox ID="TextBox2" runat="server"></asp:TextBox>
                        </td>
                    </tr>
                    <tr>
                        <td>Company Email:</td>
                        <td>
                            <asp:TextBox ID="TextBox3" runat="server"></asp:TextBox>
                        </td>
                    </tr>
                    <tr>
                        <td>Company Address:</td>
                        <td>
                            <asp:TextBox ID="TextBox4" runat="server"></asp:TextBox>
                        </td>
                    </tr>
                    <tr>
                        <td>Company Cover Images:</td>
                        <td>
                            <asp:FileUpload ID="FileUpload1" runat="server" />
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <asp:Button ID="Button1" runat="server" Text="Add Company" OnClick="Button1_Click"  />
                        </td>
                    </tr>
                </table>
            </center>
        </div>
    </form>
</body>
</html>
