﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Dashboard.aspx.cs" Inherits="Database_Connectivity.Dashboard" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div>
            <center>
                <h1>Dashboard</h1>
                <asp:Label ID="Label1" runat="server"></asp:Label>
            </center>
        </div>
    </form>
</body>
</html>
