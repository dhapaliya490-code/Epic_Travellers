﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//New Namespace
using System.Data.SqlClient;//For Connection
using System.Data;//For Dataset
using System.Configuration;//For Connection String

namespace Database_Connectivity
{
    public partial class Show_Products : System.Web.UI.Page
    {
        SqlConnection con;//For Connection
        SqlCommand cmd;//For insert, update, delete
        SqlDataAdapter da;//For Container
        DataSet ds;//For Select
        string nm;//For Name

        string s = ConfigurationManager.ConnectionStrings["dbcon"].ConnectionString;//For Connection String 
        void getcon()
        {
            con = new SqlConnection(s);
            con.Open();
        }

        void filldatalist()
        {
            int id = Convert.ToInt16(Request.QueryString["cid"]);
            da = new SqlDataAdapter("select * from Product_tbl where Prod_Comp_Id = '" + id + "'", con);
            ds = new DataSet();
            da.Fill(ds);
            DataList1.DataSource = ds;
            DataList1.DataBind();
        }
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["admin"] != null)
            {
                getcon();

                da = new SqlDataAdapter("select * from emp_tbl where Email = '" + Session["admin"] + "'", con);
                ds = new DataSet();
                da.Fill(ds);

                nm = ds.Tables[0].Rows[0]["Name"].ToString();
                string uid = ds.Tables[0].Rows[0]["Id"].ToString();
                ViewState["uid"]=uid;

                Label2.Text = "Welcome " + nm;

                filldatalist();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "cmd_dlt")
            {
                int pid = Convert.ToInt16(e.CommandArgument);
                ViewState["pid"] = pid;
                Response.Redirect("View_Details.aspx?Pid=" + ViewState["pid"]);
            }
            else if (e.CommandName == "cmd_add_cart")
            {
                int id = Convert.ToInt16(e.CommandArgument);
                int uid = Convert.ToInt16(ViewState["uid"]);
                ViewState["pid"] = id;
                cmd = new SqlCommand("insert into Cart_tbl (Cart_User_Id, Cart_Prod_Id, Quantity, Added_Date) values('" + uid + "','" + ViewState["pid"] +"','"+1+"',GETDATE())",con);
                cmd.ExecuteNonQuery();
                Response.Redirect("View_Cart.aspx");
            }
        }

        protected void LinkButton3_Click(object sender, EventArgs e)
        {
            Response.Redirect("View_Cart.aspx");
        }
    }
}