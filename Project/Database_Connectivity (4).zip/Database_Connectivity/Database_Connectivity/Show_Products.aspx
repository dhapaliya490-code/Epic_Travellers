﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Show_Products.aspx.cs" Inherits="Database_Connectivity.Show_Products" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div>
            <center>
                <h1>
                    <asp:Label ID="Label1" runat="server" Text="Company Wise Products : "></asp:Label>
                </h1>

                <asp:LinkButton ID="LinkButton3" runat="server" OnClick="LinkButton3_Click">View_Cart</asp:LinkButton>
                <br /><br />
                <asp:Label ID="Label2" runat="server" Text="Label"></asp:Label>


                <br />
                <br />
                <asp:DataList ID="DataList1" runat="server" CellSpacing="20" RepeatDirection="Horizontal" OnItemCommand="DataList1_ItemCommand">
                    <ItemTemplate>
                        <asp:Image ID="Image1" runat="server" Height="100" Width="100" ImageUrl='<%# Eval("Prod_Img") %>' />
                        <br />
                        <asp:Label ID="Label3" runat="server" Text='<%# Eval("Prod_Name") %>'></asp:Label>
                        <br />
                        <asp:Label ID="Label4" runat="server" Text='<%# Eval("Prod_Price") %>'></asp:Label>
                        <br />
                        <br />
                        <asp:LinkButton ID="LinkButton1" runat="server" CommandName="cmd_dlt" CommandArgument='<%# Eval("Prod_Id") %>'>View Details</asp:LinkButton>
                        <br />
                        <asp:LinkButton ID="LinkButton2" runat="server" CommandName="cmd_add_cart" CommandArgument='<%# Eval("Prod_Id") %>'>Add to Cart</asp:LinkButton>
                    </ItemTemplate>
                </asp:DataList>


            </center>
        </div>
    </form>
</body>
</html>
