﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//New Namespace
using System.Data.SqlClient;//For Connection
using System.Data;//For Dataset
using System.Configuration;//For Connection String

namespace Database_Connectivity
{
    public partial class Dashboard : System.Web.UI.Page
    {

        SqlConnection con;//For Connection
        SqlCommand cmd;//For insert, update, delete
        SqlDataAdapter da;//For Container
        DataSet ds;//For Select
        string nm;//For Name

        string s = ConfigurationManager.ConnectionStrings["dbcon"].ConnectionString;//For Connection String 
        void getcon()
        {
            con = new SqlConnection(s);
            con.Open();
        }

        void fillgrid()
        {
            getcon();
            da = new SqlDataAdapter("select * from emp_tbl", con);
            ds = new DataSet();
            da.Fill(ds);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["admin"] != null)
            {
                getcon();
                fillgrid();

                da = new SqlDataAdapter("select * from emp_tbl where Email = '" + Session["admin"] + "'", con);
                ds = new DataSet();
                da.Fill(ds);    

                nm = ds.Tables[0].Rows[0]["Name"].ToString();

                Label1.Text = "Welcome " + nm;
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }
    }
}