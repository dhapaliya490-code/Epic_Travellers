﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//New Namespace
using System.Data.SqlClient;//For Connection
using System.Data;//For Dataset
using System.Configuration;//For Connection String

namespace Database_Connectivity
{
    public partial class Company : System.Web.UI.Page
    {
        SqlConnection con;//For Connection
        SqlCommand cmd;//For insert, update, delete
        SqlDataAdapter da;//For Container
        DataSet ds;//For Select
        string nm;//For Name

        string s = ConfigurationManager.ConnectionStrings["dbcon"].ConnectionString;//For Connection String 
        void getcon()
        {
            con = new SqlConnection(s);
            con.Open();
        }

      

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["admin"] != null)
            {
                getcon();

                da = new SqlDataAdapter("select * from emp_tbl where Email = '" + Session["admin"] + "'", con);
                ds = new DataSet();
                da.Fill(ds);

                nm = ds.Tables[0].Rows[0]["Name"].ToString();

                Label1.Text = "Welcome " + nm;
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        void imgupload()
        {
            nm = "Company_Img/" + FileUpload1.FileName;//For fetch filename
            FileUpload1.SaveAs(Server.MapPath(nm));//Copy file on Specified folder
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Add_Product.aspx");
        }

        void clear()
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            getcon();
            imgupload();
            cmd = new SqlCommand("insert into Company_tbl(Comp_Name,Comp_Owner_name,Comp_Email,Comp_Add,Comp_Cover_img) values('"+TextBox1.Text+"','"+TextBox2.Text+"','"+TextBox3.Text+"','"+TextBox4.Text+"','"+nm+"') ", con);
            cmd.ExecuteNonQuery();
            clear();
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Show_Company.aspx");
        }
    }
}