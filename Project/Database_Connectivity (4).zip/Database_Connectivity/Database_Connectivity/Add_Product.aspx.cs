﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//New Namespace
using System.Data.SqlClient;//For Connection
using System.Data;//For Dataset
using System.Configuration;//For Connection String

namespace Database_Connectivity
{
    public partial class Product : System.Web.UI.Page
    {
        SqlConnection con;//For Connection
        SqlCommand cmd;//For insert, update, delete
        SqlDataAdapter da;//For Container
        DataSet ds;//For Select
        string nm;//For Name

        string s = ConfigurationManager.ConnectionStrings["dbcon"].ConnectionString;//For Connection String 
        void getcon()
        {
            con = new SqlConnection(s);
            con.Open();
        }

        void imgupload()
        {
            nm = "Product_Img/" + FileUpload1.FileName;//For fetch filename
            FileUpload1.SaveAs(Server.MapPath(nm));//Copy file on Specified folder
        }

        void clear()
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            TextBox6.Text = "";
            DropDownList1.ClearSelection();
        }

        void fillcompany()
        {
            getcon();
            da = new SqlDataAdapter("select * from Company_tbl", con);
            ds = new DataSet();
            da.Fill(ds);
            for(int i=0; i < ds.Tables[0].Rows.Count; i++)
            {
                DropDownList1.Items.Add(ds.Tables[0].Rows[i][1].ToString());
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            getcon();

            if (!IsPostBack)
            {
                fillcompany();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            getcon();
            imgupload();

            da = new SqlDataAdapter("select * from Company_tbl where Comp_Name = '"+DropDownList1.SelectedItem+"'", con);
            ds = new DataSet();
            da.Fill(ds);

            int id = Convert.ToInt16(ds.Tables[0].Rows[0][0]);
            ViewState["Comp_Id"] = id;

            cmd = new SqlCommand("insert into Product_tbl(Prod_Comp_Id,Prod_Name,Prod_Model,Prod_Descrip,Prod_Config,Prod_Price,Prod_Wight,Prod_Img) values('" + ViewState["Comp_Id"] +"','" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','"+TextBox6.Text+"','" + TextBox5.Text + "','" + nm + "')", con);
            cmd.ExecuteNonQuery();
            clear();
        }
    }
}