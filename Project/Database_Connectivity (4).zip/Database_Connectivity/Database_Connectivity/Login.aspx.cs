﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//New Namespace
using System.Data.SqlClient;//For Connection
using System.Data;//For Dataset
using System.Configuration;//For Connection String

namespace Database_Connectivity
{
    public partial class Login : System.Web.UI.Page
    {
        SqlConnection con;//For Connection
        SqlCommand cmd;//For insert, update, delete
        SqlDataAdapter da;//For Container
        DataSet ds;//For Select
        int i;

        string s = ConfigurationManager.ConnectionStrings["dbcon"].ConnectionString;//For Connection String 

        void getcon()
        {
            con = new SqlConnection(s);
            con.Open();
        }
        protected void Page_Load(object sender, EventArgs e)
        {
           getcon();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if(!(string.IsNullOrEmpty(TextBox1.Text)) && !(string.IsNullOrEmpty(TextBox2.Text)))
            {
                cmd = new SqlCommand("select count(*) from emp_tbl where Email = '" + TextBox1.Text + "' and Password = '" + TextBox2.Text + "'",con);
                i = Convert.ToInt16(cmd.ExecuteScalar());



                if (i > 0)
                {
                    Session["admin"] = TextBox1.Text;
                    Response.Redirect("Add_Company.aspx");
                }
                else
                {
                    Response.Write("Invalid Email or Password");
                }
            }

        }
    }
}