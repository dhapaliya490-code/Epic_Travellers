﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//New Namespace
using System.Data.SqlClient;//For Connection
using System.Data;//For Dataset
using System.Configuration;//For Connection String


namespace Database_Connectivity
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        SqlConnection con;//For Connection
        SqlCommand cmd;//For insert, update, delete
        SqlDataAdapter da;//For Container
        DataSet ds;//For Select
        string fnm;//For Imagepath

        string s = ConfigurationManager.ConnectionStrings["dbcon"].ConnectionString;//For Connection String 

        protected void Page_Load(object sender, EventArgs e)
        {
            getcon();
            fillgrid();
        }

        void getcon()
        {
            con = new SqlConnection(s);
            con.Open();
        }

        void imgupload()
        {
            fnm = "images/" + FileUpload1.FileName;//For fetch filename
            FileUpload1.SaveAs(Server.MapPath(fnm));//Copy file on Specified folder
        }

        void clear()
        {
            TextBox1.Text = "";
            RadioButtonList1.ClearSelection();
            TextBox2.Text = "";
            DropDownList1.ClearSelection();
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
        }

        void fillgrid()
        {
            getcon();
            da = new SqlDataAdapter("select * from emp_tbl",con);
            ds = new DataSet();
            da.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if(Button1.Text=="Save")
            {
                //Insert
                getcon();
                imgupload();
                cmd = new SqlCommand("insert into emp_tbl(Name,Gender,Email,Password,City,Address,Mobile,Image) values('"+TextBox1.Text+ "','"+RadioButtonList1.SelectedValue+"','" + TextBox2.Text+ "','"+TextBox5.Text+ "','"+DropDownList1.SelectedValue+ "','"+TextBox3.Text+ "','"+TextBox4.Text+ "','"+fnm+"') ", con);
                cmd.ExecuteNonQuery();
                clear();
                fillgrid();
            }
            else
            {
                //Update
                getcon();   
                cmd= new SqlCommand("update emp_tbl set Name='"+TextBox1.Text+"',Gender='"+ RadioButtonList1.SelectedValue+"',Email='"+TextBox2.Text+"',City='"+DropDownList1.SelectedValue+"',Address='"+TextBox3.Text+"',Mobile='"+TextBox4.Text+"' where id='"+ViewState["id"]+"' ",con);
                cmd.ExecuteNonQuery();
                fillgrid();
                clear();
                Button1.Text = "Save";
            }
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if(e.CommandName == "cmd_edt")
            {
                int id = Convert.ToInt16(e.CommandArgument);
                ViewState["id"] = id;
                Button1.Text = "Update";
                filldata();//paring
            }
            else
            {
                //Delete
                getcon();
                cmd = new SqlCommand("delete from emp_tbl where id = '"+e.CommandArgument+"' ",con);
                cmd.ExecuteNonQuery();
                fillgrid();
            }
        }


        void filldata()
        {
            //paring
            getcon();
            da = new SqlDataAdapter("select * from emp_tbl where id='" + ViewState["id"] +"'",con);
            ds = new DataSet();
            da.Fill(ds);

            TextBox1.Text = ds.Tables[0].Rows[0][1].ToString();
            TextBox2.Text = ds.Tables[0].Rows[0]["Email"].ToString();
            DropDownList1.SelectedValue = ds.Tables[0].Rows[0][4].ToString();
            TextBox3.Text = ds.Tables[0].Rows[0]["Address"].ToString();
            TextBox4.Text = ds.Tables[0].Rows[0][6].ToString();
            RadioButtonList1.SelectedValue = ds.Tables[0].Rows[0]["Gender"].ToString();
        }
    }
}